from django.urls import path
from . import views

# urlpatterns = [
#     path('', views.index, name='homePage'),
#     path('home', views.index, name='homePage'),
#     path('about', views.index, name='aboutPage')
# ]
urlpatterns = [
    path('', views.index, name='homePage'),
    path('home', views.index, name='homePage'),
    path('about', views.about, name='about'),
    path('catalog', views.catalog, name='catalog'),
    path('error404', views.error404, name='error404'),
    path('details', views.soon, name='details'),
    path('login', views.soon, name='login'),
    path('order', views.soon, name='order'),
    path('movie/<int:movie_id>', views.details, name='details'),
]

