var catalog = [];

function loadData(){
    $.ajax({
        url:'/api/movies',
        type: 'GET',
        success: (res) => {
            console.log('From Server',res);

            for(let x=0; x< res.objects.length; x++){
                var movie = res.objects[x];

                $('#myTable').append('<tr><td class="tdImg"><img src="' + movie.image + '" class="imgM"></td><td><a href="/movie/'+ movie.id + '">' + movie.title + '</a></td><td>' + movie.release_year + '</td><td>' + movie.price + '</td><td>' + movie.in_stock + '</td></tr>');
            }
        },
        error: (errorDetails) => {
            console.log(errorDetails);
        }
    });
}

function init(){
    console.log("Catalog page");
    loadData();
}

window.onload =  init; 